from django.apps import AppConfig


class HomesConfig(AppConfig):
    name = 'homes'
